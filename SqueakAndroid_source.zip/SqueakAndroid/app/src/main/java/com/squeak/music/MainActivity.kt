package com.squeak.music

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF24212A)
private val Muted = Color(0xFF85808C)
private val Canvas = Color(0xFFFAF9FB)
private val Lilac = Color(0xFFE9DDF8)
private val Pink = Color(0xFFF6DCEB)
private val Accent = Color(0xFF9A70B8)

// DEMO ONLY. This value is visible in the app source and is NOT secure.
private const val DEMO_ADMIN_CODE = "SQUEAK-ADMIN-2026"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SqueakApp() }
    }
}

@Composable
fun SqueakApp() {
    var tab by remember { mutableStateOf("Home") }
    var adminOpen by remember { mutableStateOf(false) }
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Accent,
            background = Canvas,
            surface = Color.White,
            onBackground = Ink,
            onSurface = Ink
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Canvas) {
            if (adminOpen) {
                AdminScreen(onBack = { adminOpen = false })
            } else {
                Column(Modifier.fillMaxSize()) {
                    when (tab) {
                        "Home" -> HomeScreen()
                        "Search" -> SearchScreen()
                        "Library" -> LibraryScreen()
                        else -> ProfileScreen(
                            code = code,
                            onCodeChange = { code = it; error = false },
                            error = error,
                            onAdmin = {
                                if (code == DEMO_ADMIN_CODE) {
                                    adminOpen = true
                                    error = false
                                } else error = true
                            }
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    NavigationBar(containerColor = Color.White) {
                        val items = listOf(
                            Triple("Home", Icons.Default.Home, "Home"),
                            Triple("Search", Icons.Default.Search, "Search"),
                            Triple("Library", Icons.Default.LibraryMusic, "Library"),
                            Triple("Profile", Icons.Default.Person, "Profile")
                        )
                        items.forEach { (label, icon, key) ->
                            NavigationBarItem(
                                selected = tab == key,
                                onClick = { tab = key },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label, fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Accent,
                                    indicatorColor = Lilac
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PageTitle(kicker: String, title: String, subtitle: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(kicker.uppercase(), color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Text(title, color = Ink, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        if (subtitle != null) Text(subtitle, color = Muted, fontSize = 14.sp)
    }
}

@Composable
fun HomeScreen() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(22.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item { PageTitle("Your space", "Good music.\nNo rules.", "A little place for everything you love.") }
        item {
            Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = Lilac)) {
                Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("SMART WAVE", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Text("A mix made around you.", fontSize = 23.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                    Text("Your likes, discoveries and unexpected favourites.", color = Ink.copy(alpha = .7f))
                    Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = Ink), shape = RoundedCornerShape(14.dp)) {
                        Text("Explore mix")
                    }
                }
            }
        }
        item { SectionHeading("Made for you") }
        item { MusicRow("1999", "Charli XCX", "Pop · 2019") }
        item { MusicRow("Faceshopping", "SOPHIE", "Experimental · 2018") }
        item { MusicRow("Dreamer", "Charli XCX", "Electronic · 2017") }
        item { SectionHeading("Your assistant") }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Pink), shape = RoundedCornerShape(22.dp)) {
                Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).background(Color.White, CircleShape), contentAlignment = Alignment.Center) {
                        Text("Z", color = Accent, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Zoe", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                        Text("Ask me to find your next favourite.", color = Muted, fontSize = 13.sp)
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Accent)
                }
            }
        }
    }
}

@Composable
fun SectionHeading(text: String) {
    Text(text, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
}

@Composable
fun MusicRow(title: String, artist: String, meta: String) {
    Row(
        Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(52.dp).background(Lilac, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.MusicNote, contentDescription = null, tint = Accent)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text("$artist · $meta", color = Muted, fontSize = 12.sp)
        }
        IconButton(onClick = {}) { Icon(Icons.Default.PlayArrow, contentDescription = "Play") }
    }
}

@Composable
fun SearchScreen() {
    var query by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        PageTitle("Discover", "Search", "Find tracks, artists and mixes.")
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Songs, artists, albums…") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(16.dp),
            singleLine = true
        )
        SectionHeading(if (query.isBlank()) "Popular right now" else "Search results")
        if (query.isBlank()) {
            listOf("Hyperpop", "Electronic", "Experimental", "Pop").forEach {
                Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp)).padding(18.dp)) {
                    Text(it, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.ArrowOutward, null, tint = Muted)
                }
            }
        } else {
            Text("Search is a visual demo. Connect a music catalogue/API to show real results.", color = Muted)
        }
    }
}

@Composable
fun LibraryScreen() {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        PageTitle("Your collection", "Library", "Everything you save, in one place.")
        listOf("Liked songs", "Playlists", "Recently played", "Your edits").forEachIndexed { index, item ->
            Row(
                Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).clickable {}.padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(listOf(Icons.Default.Favorite, Icons.Default.QueueMusic, Icons.Default.History, Icons.Default.Edit)[index], null, tint = Accent)
                Spacer(Modifier.width(14.dp))
                Text(item, Modifier.weight(1f), fontWeight = FontWeight.Medium)
                Icon(Icons.Default.ChevronRight, null, tint = Muted)
            }
        }
    }
}

@Composable
fun ProfileScreen(
    code: String,
    onCodeChange: (String) -> Unit,
    error: Boolean,
    onAdmin: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        PageTitle("Account", "Your profile", "Make Squeak feel like yours.")
        Card(colors = CardDefaults.cardColors(containerColor = Lilac), shape = RoundedCornerShape(22.dp)) {
            Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(58.dp).background(Color.White, CircleShape), contentAlignment = Alignment.Center) {
                    Text("P", fontSize = 24.sp, color = Accent, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Peepy listener", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Guest account", color = Muted, fontSize = 13.sp)
                }
            }
        }
        SectionHeading("Settings")
        listOf("Appearance", "Privacy", "Playback", "About Squeak").forEach {
            Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(15.dp)).padding(16.dp)) {
                Text(it, Modifier.weight(1f))
                Icon(Icons.Default.ChevronRight, null, tint = Muted)
            }
        }
        Spacer(Modifier.height(4.dp))
        Text("ADMIN ACCESS · DEMO", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        OutlinedTextField(
            value = code, onValueChange = onCodeChange,
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Administrator code") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions.Default,
            singleLine = true,
            shape = RoundedCornerShape(14.dp)
        )
        Button(onClick = onAdmin, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
            Text("Open admin panel")
        }
        if (error) Text("Incorrect demo code.", color = Color(0xFFB3261E), fontSize = 13.sp)
        Text("The demo code is written in README. Never use a client-side code for real admin security.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun AdminScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Text("Administration", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        }
        Text("SQUEAK CONTROL CENTRE", color = Accent, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.5.sp)
        Card(colors = CardDefaults.cardColors(containerColor = Lilac), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(18.dp)) {
                Text("Demo administrator", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("You are viewing a local prototype. Changes are not saved to a server.", color = Muted, fontSize = 13.sp)
            }
        }
        listOf(
            Triple("Users", "View accounts and roles", Icons.Default.People),
            Triple("Moderation", "Reports, reviews and appeals", Icons.Default.Gavel),
            Triple("Music catalogue", "Tracks, edits and metadata", Icons.Default.LibraryMusic),
            Triple("Subscriptions", "Plans and access status", Icons.Default.Star),
            Triple("App settings", "Feature switches and configuration", Icons.Default.Settings),
            Triple("Security log", "Sign-ins and suspicious activity", Icons.Default.Security)
        ).forEach { (title, subtitle, icon) ->
            Row(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(16.dp)).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = Accent)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, fontWeight = FontWeight.SemiBold)
                    Text(subtitle, color = Muted, fontSize = 12.sp)
                }
                Icon(Icons.Default.ChevronRight, null, tint = Muted)
            }
        }
    }
}
