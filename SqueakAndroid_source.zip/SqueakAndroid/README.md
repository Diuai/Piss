# Squeak Android starter

A minimal native Android prototype built with Kotlin + Jetpack Compose.

## Open and build
1. Install Android Studio.
2. Choose **Open** and select this `SqueakAndroid` folder.
3. Wait for Gradle sync. If Android Studio asks to install Android SDK 35, accept.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is usually created at `app/build/outputs/apk/debug/app-debug.apk`.

## Demo administrator access
The prototype admin code is:

`SQUEAK-ADMIN-2026`

Enter it in Profile → Administrator code → Open admin panel.

## Important limitations
- This is a UI starter, not a finished music service.
- Search, playback, accounts, comments, AI, subscriptions and admin actions are placeholders.
- The admin code is intentionally client-side for demonstration. Anyone who can inspect the APK/source can discover or bypass it.
- Before public release, implement authentication and role checks on a backend; never trust a role or secret stored only in the app.
- Do not collect real user data or payments until privacy, security and age-appropriate safeguards are implemented.

## Project details
- Package: `com.squeak.music`
- Minimum Android: 7.0 (API 24)
- Target / compile SDK: 35

## Build APK automatically with GitHub Actions (no Android Studio needed)
1. Create a new repository on GitHub.
2. Upload the contents of this project folder to the repository (the `.github/workflows/android.yml` file must be included).
3. Open the repository's **Actions** tab and select **Build Squeak APK**.
4. If it did not start automatically, press **Run workflow**.
5. When the run finishes successfully, open it and download the **Squeak-debug-APK** artifact. Unzip that artifact to get `app-debug.apk`.

The generated debug APK is suitable for testing, not a Play Store release. A production release needs a properly protected signing key and backend security.
